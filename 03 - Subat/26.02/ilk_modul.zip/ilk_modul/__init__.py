# -*- coding: utf-8 -*-
from . import controllers
from custom_addons.ilk_modul import models
from . import wizard
from custom_addons.ilk_modul.models import partner