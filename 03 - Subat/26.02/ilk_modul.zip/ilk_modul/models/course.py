from odoo import models, fields, api

class Course(models.Model):
    _name = 'ilk_modul.course'
    name = fields.Char(string="Title", required=True)
    description = fields.Text()

