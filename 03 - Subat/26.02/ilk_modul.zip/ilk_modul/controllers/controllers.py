# -*- coding: utf-8 -*-
from odoo import http

# class IlkModul(http.Controller):
#     @http.route('/ilk_modul/ilk_modul/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/ilk_modul/ilk_modul/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('ilk_modul.listing', {
#             'root': '/ilk_modul/ilk_modul',
#             'objects': http.request.env['ilk_modul.ilk_modul'].search([]),
#         })

#     @http.route('/ilk_modul/ilk_modul/objects/<model("ilk_modul.ilk_modul"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('ilk_modul.object', {
#             'object': obj
#         })